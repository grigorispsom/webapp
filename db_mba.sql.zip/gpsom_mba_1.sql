-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Φιλοξενητής: localhost:3306
-- Χρόνος δημιουργίας: 29 Μαρ 2022 στις 02:28:12
-- Έκδοση διακομιστή: 5.6.41-84.1
-- Έκδοση PHP: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `gpsom_mba_1`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `dept`
--

CREATE TABLE `dept` (
  `deptid` int(11) NOT NULL,
  `deptlevelid` int(11) DEFAULT '0',
  `depttitle` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `empleave`
--

CREATE TABLE `empleave` (
  `leaveid` int(11) NOT NULL,
  `userid` int(11) DEFAULT '0',
  `leavetypeid` int(11) DEFAULT '0',
  `leavestart` datetime DEFAULT NULL,
  `leaveend` datetime DEFAULT NULL,
  `phoneleave` tinyint(1) NOT NULL DEFAULT '0',
  `superviapprove` datetime(1) DEFAULT NULL,
  `leaveapproveddate` datetime DEFAULT NULL,
  `leaveapprovedby` int(11) DEFAULT '0',
  `leavedenieddate` datetime DEFAULT NULL,
  `leavedeniedreason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empleavereqdate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `leavelimits`
--

CREATE TABLE `leavelimits` (
  `leavelimitsid` int(11) NOT NULL,
  `userid` int(11) DEFAULT '0',
  `yearperiodid` int(11) DEFAULT '0',
  `leavetypeid` int(11) DEFAULT '0',
  `maxleaves` int(11) DEFAULT '0',
  `leavelimitsreqdate` datetime DEFAULT NULL,
  `leavelimitsapproveddate` datetime DEFAULT NULL,
  `leavelimitsdenydate` datetime DEFAULT NULL,
  `leavelimitscomments` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `leavetype`
--

CREATE TABLE `leavetype` (
  `leavetypeid` int(11) NOT NULL,
  `leavetypetitle` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `oauthprovider` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oauthuid` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobilephone` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `createddate` datetime DEFAULT NULL,
  `lastlogindate` datetime DEFAULT NULL,
  `usergroupid` int(11) DEFAULT '0',
  `deptid` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `usergroup`
--

CREATE TABLE `usergroup` (
  `usergroupid` int(11) NOT NULL,
  `usergrouplevel` int(11) DEFAULT '0',
  `usergrouptitle` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `yearperiod`
--

CREATE TABLE `yearperiod` (
  `yearperiodid` int(11) NOT NULL,
  `yearperiodstart` datetime DEFAULT NULL,
  `yearperiodend` datetime DEFAULT NULL,
  `yearperiodtitle` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `dept`
--
ALTER TABLE `dept`
  ADD PRIMARY KEY (`deptid`);

--
-- Ευρετήρια για πίνακα `empleave`
--
ALTER TABLE `empleave`
  ADD PRIMARY KEY (`leaveid`),
  ADD KEY `idx_02865e3b857d425c` (`leavetypeid`),
  ADD KEY `idx_4be6911af0ad0ce2` (`userid`);

--
-- Ευρετήρια για πίνακα `leavelimits`
--
ALTER TABLE `leavelimits`
  ADD PRIMARY KEY (`leavelimitsid`),
  ADD KEY `idx_1cc26d0852d3cbf0` (`leavetypeid`),
  ADD KEY `idx_7dad6dfceff89405` (`userid`),
  ADD KEY `idx_1d16075a71ce0431` (`yearperiodid`);

--
-- Ευρετήρια για πίνακα `leavetype`
--
ALTER TABLE `leavetype`
  ADD PRIMARY KEY (`leavetypeid`);

--
-- Ευρετήρια για πίνακα `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`),
  ADD KEY `dept_fkey` (`deptid`) USING BTREE,
  ADD KEY `usergroup_fkey` (`usergroupid`) USING BTREE;

--
-- Ευρετήρια για πίνακα `usergroup`
--
ALTER TABLE `usergroup`
  ADD PRIMARY KEY (`usergroupid`);

--
-- Ευρετήρια για πίνακα `yearperiod`
--
ALTER TABLE `yearperiod`
  ADD PRIMARY KEY (`yearperiodid`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `dept`
--
ALTER TABLE `dept`
  MODIFY `deptid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT για πίνακα `empleave`
--
ALTER TABLE `empleave`
  MODIFY `leaveid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT για πίνακα `leavelimits`
--
ALTER TABLE `leavelimits`
  MODIFY `leavelimitsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT για πίνακα `leavetype`
--
ALTER TABLE `leavetype`
  MODIFY `leavetypeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT για πίνακα `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT για πίνακα `usergroup`
--
ALTER TABLE `usergroup`
  MODIFY `usergroupid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT για πίνακα `yearperiod`
--
ALTER TABLE `yearperiod`
  MODIFY `yearperiodid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Περιορισμοί για άχρηστους πίνακες
--

--
-- Περιορισμοί για πίνακα `empleave`
--
ALTER TABLE `empleave`
  ADD CONSTRAINT `fk_e74a3ea3d4a4a30a` FOREIGN KEY (`leavetypeid`) REFERENCES `leavetype` (`leavetypeid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_f735d01d812eec6b` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Περιορισμοί για πίνακα `leavelimits`
--
ALTER TABLE `leavelimits`
  ADD CONSTRAINT `fk_0c67e84fd7529e7c` FOREIGN KEY (`yearperiodid`) REFERENCES `yearperiod` (`yearperiodid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_7364cd72a262f622` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_8a7959251eae31b5` FOREIGN KEY (`leavetypeid`) REFERENCES `leavetype` (`leavetypeid`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Περιορισμοί για πίνακα `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_b42b546c55ab1b4f` FOREIGN KEY (`usergroupid`) REFERENCES `usergroup` (`usergroupid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_d805ae2fb5d3d4c5` FOREIGN KEY (`deptid`) REFERENCES `dept` (`deptid`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
